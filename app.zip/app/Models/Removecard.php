<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Removecard extends Model
{
    protected $table = 'removecard_request';
    protected $primaryKey = 'id';
}
?>