<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CarImages extends Model
{
    protected $table = 'cars_images';
    protected $primaryKey = 'id';

    
  
}
?>